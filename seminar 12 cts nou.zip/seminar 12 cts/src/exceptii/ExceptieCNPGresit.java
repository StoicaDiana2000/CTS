package exceptii;

public class ExceptieCNPGresit extends IllegalArgumentException{
}
