package seminar6;

public interface Builder {

    Autobuz build();
}
